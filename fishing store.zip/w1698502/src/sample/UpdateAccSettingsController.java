package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class UpdateAccSettingsController extends Controller {


    @FXML
    private Label lblupdateUsernameaccvalidation;

    @FXML
    private Label lblupdateEmailaccvalidation;

    @FXML
    private Label lblupdatePasswordaccvalidation;

    @FXML
    private TextField updatenewUsername;

    @FXML
    private TextField updatenewEmail;

    @FXML
    private TextField updateconfirmPassword;

    @FXML
    private TextField updatenewPassword;




    //  customer,owner,staff username update methode

    //update account username
    public void accUsernameUpdate() {


        //get the data base connection
        DatabaseConnection connectClass = new DatabaseConnection();
        Connection connection = connectClass.getConnection();

        if (updatenewUsername.getText().trim().isEmpty()) {
               //if user press the button without enter any username value to text field this statement will execute.
            lblupdateUsernameaccvalidation.setText("Please fill the username box before update..");

        } else {

            try {

                String sql = "UPDATE ownerdb SET username=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                 // select the the table and the row by email when owner log to account and update that row username colomn data value.

                PreparedStatement prs = connection.prepareStatement(sql);
                  //update new owner username to database.
                prs.setString(1, updatenewUsername.getText());


                prs.execute();
                // system aware when the owner's username is update
                lblupdateUsernameaccvalidation.setText("Username Update Successful");

            } catch (Exception e) {

            }


            try {
                String sql = "UPDATE staffdb SET username=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                // select the the table and the row by email when staff memeber log to account and update that row username colomn data value.


                PreparedStatement prs = connection.prepareStatement(sql);
                //update new staff member username to database.
                prs.setString(1, updatenewUsername.getText());


                prs.execute();
                // system aware when the staff member username is update
                lblupdateUsernameaccvalidation.setText("Username Update Successful");

            } catch (Exception e) {

            }

            try {
                String sql = "UPDATE customerdb SET username=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                // select the the table and the row by email when customer log to account and update that row username colomn data value.


                PreparedStatement prs = connection.prepareStatement(sql);
                //update new customer username to database.
                prs.setString(1, updatenewUsername.getText());


                prs.execute();
                // system aware when the customer username is update
                lblupdateUsernameaccvalidation.setText("Username Update Successful");

            } catch (Exception e) {

            }


        }


    }

     //update account email
    public void accEmailUpdate(ActionEvent event) throws SQLException, IOException {

        DatabaseConnection connectClass = new DatabaseConnection();
        Connection connection = connectClass.getConnection();


        if (updatenewEmail.getText().trim().isEmpty()) {
            //if user press the button without enter any email value to text field this statement will execute.
            lblupdateEmailaccvalidation.setText("Please fill the email box before update.");

        } else {

            String data1 = "SELECT `email` FROM `staffdb` WHERE `email`=? ";    //get emails from database
            String data2 = "SELECT `email` FROM `customerdb` WHERE `email`=? ";    //get values from 3 tables
            String data3 = "SELECT `email` FROM `ownerdb` WHERE `email`=? ";


            if (Validation.check(data1, updatenewEmail.getText()) == 0 && Validation.check(data2, updatenewEmail.getText()) == 0 && Validation.check(data3, updatenewEmail.getText()) == 0) {
                 //if user input new email is not in the dtatabase then thisl ine will excicute

                if (Validation.validateEmail(updatenewEmail.getText())) {
                       //check whether the email is match to email structure

                    try {
                        String sql = "UPDATE ownerdb SET  email=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                    // select the the table and the row by email when owner  log to account and update that row email colomn data value.

                        PreparedStatement prs = connection.prepareStatement(sql);

                         //update the email
                        prs.setString(1, updatenewEmail.getText());

                        prs.execute();




                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    try {
                        String sql = "UPDATE staffdb SET  email=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                       // select the the table and the row by email when staff  log to account and update that row email colomn data value.

                        PreparedStatement prs = connection.prepareStatement(sql);

                        //update the email
                        prs.setString(1, updatenewEmail.getText());

                        prs.execute();



                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        String sql = "UPDATE customerdb SET  email=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                        // select the the table and the row by email when customer  log to account and update that row email colomn data value.



                        PreparedStatement prs = connection.prepareStatement(sql);
                        //update the email

                        prs.setString(1, updatenewEmail.getText());

                        prs.execute();



                    } catch (Exception e) {
                        e.printStackTrace();
                    } //swicth to next interface
                    Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
                    switchScene(event,root,"Jeff's Fishing Shack");

                } else {  // if the email is not match to email structure then this statemen will excicute
                    lblupdateEmailaccvalidation.setText("Enter Your email correctly.");
                }

            } else {
                // if the update email is already in database then this statemenet will excicute
                lblupdateEmailaccvalidation.setText("New Email is already exist.");
            }


        }

    }
    //update account password
    public void accPasswordUpdate() {

        DatabaseConnection connectClass = new DatabaseConnection();
        Connection connection = connectClass.getConnection();


        if ( updateconfirmPassword.getText().trim().isEmpty() || updatenewPassword.getText().trim().isEmpty()) {
            //if user press the button without enter any password values to text fields this statement will execute.
            lblupdatePasswordaccvalidation.setText("Please fill the password box before update.");

        } else {

            if (Validation.validationPassword(updatenewPassword.getText()) >= 2) {
                //check whether the input password has atleast 8 characters with 2 non-alphabetic chrachtars

                if (updatenewPassword.getText().equals(updateconfirmPassword.getText())) {
                    //check whether the password is matched to confirm pssword
                    try {
                        String sql = "UPDATE ownerdb SET  password=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                        //select the database raw when the user log to his account and get  owner's email locatin an then update the rawpassword



                        PreparedStatement prs = connection.prepareStatement(sql);


                        prs.setString(1, updatenewPassword.getText());
                        //update the password

                        prs.execute();

                        lblupdatePasswordaccvalidation.setText("Password Update Successful");

                    } catch (Exception e) {

                    }


                    try {
                        String sql = "UPDATE staffdb SET  password=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                        //select the database raw when the user log to his account and get  staff memeber email locatin an then update the rawpassword



                        PreparedStatement prs = connection.prepareStatement(sql);


                        prs.setString(1, updatenewPassword.getText());
                        //update the password

                        prs.execute();

                        lblupdatePasswordaccvalidation.setText("Password Update Successful");


                    } catch (Exception e) {

                    }

                    try {
                        String sql = "UPDATE customerdb SET  password=? WHERE email in('" + LoginAndRegisterController.saveEmail + "')";
                        //select the database raw when the user log to his account and get customers's email locatin an then update the rawpassword



                        PreparedStatement prs = connection.prepareStatement(sql);

                        prs.setString(1, updatenewPassword.getText());
                        //update the password

                        prs.execute();

                        lblupdatePasswordaccvalidation.setText("Password Update Successful");


                    } catch (Exception e) {

                    }


                } else {
                    //if password doesn't match to confirm password then this line will excicute
                    lblupdatePasswordaccvalidation.setText("Enter above password.");
                }
            } else {
                //if the password doesn't have 8 characaters with 2 non numeric characaters then this ststaement will excicute.
                lblupdatePasswordaccvalidation.setText("Enter 8 character password \nwith 2 non-alphabetic characters.");
            }

        }

    }

    public void customerBack(ActionEvent event) throws IOException {
         //back to the customer account
        Parent root = FXMLLoader.load(getClass().getResource("CustomerAccount.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }

    public void OwnerBack(ActionEvent event) throws IOException {
        //back to the owner account
        Parent root = FXMLLoader.load(getClass().getResource("OwnerAccount.fxml"));
       switchScene(event,root,"Jeff's Fishing Shack");

    }

    public void staffMemberBack(ActionEvent event) throws IOException {
        //back to the staff memeber account
        Parent root = FXMLLoader.load(getClass().getResource("StaffMemberAccount.fxml"));
       switchScene(event,root,"Jeff's Fishing Shack");

    }
}





