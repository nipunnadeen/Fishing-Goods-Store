package sample;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {


    //this methode check whether the input match for  gmail type
    public static boolean validateEmail(String email) {


        Pattern pat = Pattern.compile("[a-zA-Z0-9][a-zA-Z0-9._]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
        //first user can input numbers or letters then it must like @ then like gmail,yahoo,hotmail and finally " . " then the next word is ike com or lk etc....
        Matcher compare = pat.matcher(email);
        //match the input is like a email

        if (compare.find() && compare.group().equals(email)) {  //if it's correct then then its true
            return true;

        } else {
            //if it's incorrect then value return false
            return false;
        }

    }



    //this method check whether the user input is match to following conditions
    public static int validationPassword(String pass) {

        int characters = pass.length();


         // check the characters is high than 8
        if (characters>=8) {

            //now user must enter at least 2  non-numaric characters and it check every characters using by replaceAll
            int cSign = pass.replaceAll("[a-zA-Z0-9]*","").length(); // user can input sign or letters but it
            int cNum = pass.replaceAll("\\D","").length(); //user can input any numbers

            int value = (cNum + cSign);
            //get the 2 values and return the value if its true
            return value;

        } else {
            //if its wrong it will return value 1
            return 1;
        }


    }

     //this methode check the user input is already in the database or not in the database
    public static int check(String datacheck, String mail) throws SQLException {


        //get the database connection
        DatabaseConnection connectClass = new DatabaseConnection();
        Connection connection=connectClass.getConnection();



        PreparedStatement pstObj = connection.prepareStatement(datacheck);
        //prepare the string value
        pstObj.setString(1, mail);




        ResultSet res = pstObj.executeQuery();
         //execute the query
        int countNumber = 0;

        if (res.next()) {
            countNumber = countNumber + 1;
            //check its already their
        }

        return countNumber;

    }
      //this methode check if the user input id is already their in the database
    public static int storeCheckID(String storeDataCheck, String id) throws SQLException {

        DatabaseConnection connectClass = new DatabaseConnection();
        Connection connection=connectClass.getConnection();

        PreparedStatement pitem =  connection.prepareStatement(storeDataCheck);
        pitem.setString(1,id);
        //set the result
        ResultSet res = pitem.executeQuery();

        int countNumber = 0;
         //if the input is already their then it returns 1
        if (res.next()) {
            countNumber = countNumber + 1;

        }

        return countNumber;

    }
    //this methode check if the user input item name is already their in the database
    public static int storeCheckItemName(String storeDataCheck, String itemName) throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        PreparedStatement pitem =  connection.prepareStatement(storeDataCheck);
        pitem.setString(1,itemName);
        //set the result
        ResultSet res = pitem.executeQuery();

        int countNumber = 0;
        //if the input is already their then it returns 1
        if (res.next()) {
            countNumber = countNumber + 1;

        }

        return countNumber;

    }
    //this methode check if the user input item name is already their in the databasee
    public static int storeCheckCode(String storeDataCheck, String code) throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        PreparedStatement pitem =  connection.prepareStatement(storeDataCheck);
        pitem.setString(1,code);
        //set the result
        ResultSet res = pitem.executeQuery();

        int countNumber = 0;
        //if the input is already their then it returns 1
        if (res.next()) {
            countNumber = countNumber + 1;

        }

        return countNumber;

    }





}