package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;


import java.io.IOException;

public class CustomerAccountController extends Controller {



    public void Shop(ActionEvent event) throws IOException {


         //switch to store interface
        Parent root = FXMLLoader.load(getClass().getResource("CustomerShopItems.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");



    }

    public void customerAccountSettings(ActionEvent event) throws IOException {


         //switch to account setting interface
        Parent root = FXMLLoader.load(getClass().getResource("CustomerAccSettings.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");




    }

    public void logout(ActionEvent event) throws IOException {


           //switch back to login page
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");




    }

}
