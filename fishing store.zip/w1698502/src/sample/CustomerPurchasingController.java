package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

import java.io.IOException;

public class CustomerPurchasingController extends Controller {


public void pay(){


}

    public void back(ActionEvent event) throws IOException {
        //back to the customers account
        Parent root = FXMLLoader.load(getClass().getResource("CustomerShopItems.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");
    }





}
