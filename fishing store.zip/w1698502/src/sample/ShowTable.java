package sample;

//Store details class.
public class ShowTable {


    private String ID;
    private String ItemName;
    private String Code;
    private String Price;
    private String Available;

    public ShowTable(String ID, String ItemName, String Code, String Price, String Available){

        this.ID = ID;
        this.ItemName = ItemName;
        this.Code = Code;
        this.Price = Price;
        this.Available = Available;

    }

    public ShowTable(String ItemName) {

        this.ItemName = ItemName;

    }

    public String getID() {
        return ID;
    }


    public void setID(String ID) {
        this.ID = ID;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        this.ItemName = itemName;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        this.Code = code;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }

    public String getAvailable() {
        return Available;
    }

    public void setAvailable(String Available) {
        this.Available = Available;
    }

}