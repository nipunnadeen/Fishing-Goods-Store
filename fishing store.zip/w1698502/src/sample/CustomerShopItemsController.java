package sample;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

//customer shop items controller class.
public class CustomerShopItemsController extends Controller implements Initializable  {





//table view and table collen names
    @FXML
    private TableView<ShowTable> table;

    @FXML
    private TableColumn<ShowTable, String> collomn_ID;

    @FXML
    private TableColumn<ShowTable, String> collomn_ItemName;

    @FXML
    private TableColumn<ShowTable, String> collomn_Code;

    @FXML
    private TableColumn<ShowTable, String> collomn_Price;

    @FXML
    private TableColumn<ShowTable, String> collomn_Available;

    @FXML
    private ComboBox<ShowTable> comList;

    @FXML
    private Label lblChooseValueValidation;

    @FXML
    private Label lblTotalPrice;

    @FXML
    private TextField availability;

    @FXML
    private TableView<CustomerAddCartDetails> cartTable;

    @FXML
    private TableColumn<CustomerAddCartDetails, String> collmnProductItemName;

    @FXML
    private TableColumn<CustomerAddCartDetails, String> collmnProductQuantity;

    @FXML
    private TableColumn<CustomerAddCartDetails, String> collmnProductTotal;



    private ObservableList<ShowTable> obsList = FXCollections.observableArrayList();
    //observe lists for first table and combo box.
    private ObservableList<ShowTable> comboList = FXCollections.observableArrayList();



    @Override
    public void initialize(URL location, ResourceBundle resources) { // whwn the methode is initialize ,it loads first than other methods.

        DatabaseConnection connectClass = new DatabaseConnection(); //call to database connection class to get the connection
        Connection connection = connectClass.getConnection();

        try{
                    //get store data from database
            ResultSet res = connection.createStatement().executeQuery("SELECT * FROM `storedb`");
                   //get itemname data from the database
            ResultSet resCombo = connection.createStatement().executeQuery("SELECT `ItemName` FROM `storedb`");

            while(res.next()){
                //get the whole colomns datas from database table.
                obsList.add(new ShowTable(res.getString("ID"), res.getString("ItemName"), res.getString("Code"), res.getString("Price"), res.getString("Available")));

            }

            while(resCombo.next()){
                   //get the itemName colomn data from database storedb table.
                comboList.add(new ShowTable(resCombo.getString("ItemName")));

            }

        }
         // when the eror comes it gives a exception
        catch(SQLException ex){
            ex.printStackTrace();
        }
           //set the database colomn vaalues to table colomns
        collomn_ID.setCellValueFactory(new PropertyValueFactory<>("ID"));  //set the database id value to table id collomn.
        collomn_ItemName.setCellValueFactory(new PropertyValueFactory<>("ItemName"));//set the database ItemName value to table ItemName collomn.
        collomn_Code.setCellValueFactory(new PropertyValueFactory<>("Code"));   //set the database Code value to table Code collomn.
        collomn_Price.setCellValueFactory(new PropertyValueFactory<>("Price"));//set the database Price value to table Price collomn.
        collomn_Available.setCellValueFactory(new PropertyValueFactory<>("Available"));//set the database Available value to table Available collomn.

        table.setItems(obsList);    // set the final values to table.
        comList.setItems(comboList);   // set the ItemName values to combo box.

        StringConverter<ShowTable> convertNames = new StringConverter<>() {   //convert combo box values to string

            @Override
            public String toString(ShowTable obj) {
                return obj.getItemName();
            }
             // when get the values from database to combo  box it show some code so this string converter helps to convert values to string
            @Override
            public ShowTable fromString(String string) {
                return null;
            }  //get the values
        };
        comList.setConverter(convertNames);  // convert combo box details to string

    }

    private ObservableList<CustomerAddCartDetails> tableItems = FXCollections.observableArrayList();

    public void addToTable() throws SQLException {



        String shopProductName = comList.getValue().getItemName();  //store the select combolist item name values.
        String shopProductQuantity = availability.getText();  //store the select quantity values.
        String priceValue = "";  //store the select combolist item name's price values.


        if((availability.getText().trim().isEmpty())||(comList.getSelectionModel().isEmpty())){
       //if customer doesn't input any quantity this statement will execute.
            lblChooseValueValidation.setText("Enter number before add to the table.");

        }

        else{

            lblChooseValueValidation.setText("");
            //get the connection of database
            DatabaseConnection connectClass = new DatabaseConnection();
            Connection connection = connectClass.getConnection();
             // search the item name row and get that name's price value from the database table
            String dbStoreCheck = "SELECT `Price` FROM `storedb` WHERE `ItemName`='"+shopProductName+"'";

            //execute the query
            ResultSet res = connection.createStatement().executeQuery(dbStoreCheck);

            while(res.next()){
                 //get the select item price
                priceValue = res.getString("Price");

            }

            int itemAvailability = Integer.parseInt(shopProductQuantity);  //pass the int values
              //   pass quantity values

            int itemPrice = Integer.parseInt(priceValue); //pass the price value of item names.

            int total = itemAvailability * itemPrice; //get the final price of the select item name and its quantity
            String totalPrice = String.valueOf(total);
            //add the values
            tableItems.add(new CustomerAddCartDetails(shopProductName,shopProductQuantity,totalPrice));
               //set values to each coloumn
            collmnProductItemName.setCellValueFactory(new PropertyValueFactory<>("TableItemName"));
            collmnProductQuantity.setCellValueFactory(new PropertyValueFactory<>("TableQuantity"));  //set the values to every  colomn
            collmnProductTotal.setCellValueFactory(new PropertyValueFactory<>("TableTotal"));

            cartTable.setItems(tableItems);

            CustomerAddCartDetails cartPrice = new CustomerAddCartDetails();
            ArrayList<String> arlist = new ArrayList<>();

            for(int y = 0; y < cartTable.getItems().size(); y++){

                cartPrice = cartTable.getItems().get(y); //get the cart whole price values by a loop
                arlist.add(cartPrice.getTableTotal());//store the values in a arraylist

            }

            int finalTotal = 0;

            for (String totalAmount : arlist) {
                //get the total amount
                String productCost = String.valueOf(totalAmount);
                 //get the string value of amount
                int ft = Integer.parseInt(productCost);
                finalTotal = finalTotal + ft;//calculate the final price

                lblTotalPrice.setText(String.valueOf(finalTotal));

            }

        }

    }
    //clear the cart table method.
    public void tableClear() {

        for (int x = 0; x<cartTable.getItems().size(); x++) {   //get the whole data of the table and delete them by loop
            cartTable.getItems().clear();
        }

        lblTotalPrice.setText("");

    }

    public void deleteSelectProducts(){

        ObservableList<CustomerAddCartDetails> allProduct,oneProduct;
         // delete customers selected product
        allProduct=cartTable.getItems();
        //select the items of the table
        oneProduct=cartTable.getSelectionModel().getSelectedItems();
        //to remove all products one by one
        oneProduct.forEach(allProduct::remove);

    }

    public void buy(ActionEvent event) throws IOException {
        //back to the customers account
        Parent root = FXMLLoader.load(getClass().getResource("CustomerPurchasing.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");
    }


    public void back(ActionEvent event) throws IOException {
            //back to the customers account
        Parent root = FXMLLoader.load(getClass().getResource("CustomerAccount.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");
    }


}