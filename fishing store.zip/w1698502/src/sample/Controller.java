package sample;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Controller {

         // this is the parent class methode
    public static void switchScene(ActionEvent event, Parent switchPage, String pageTitle) {

        Stage primaryStage = new Stage();

        ((Node) (event.getSource())).getScene().getWindow().hide();

        primaryStage.setTitle(pageTitle);
        primaryStage.setScene(new Scene(switchPage, 1000, 700));
        primaryStage.show();

    }



}
