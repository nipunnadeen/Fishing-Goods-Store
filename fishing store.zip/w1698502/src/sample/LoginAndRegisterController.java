package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;


public class LoginAndRegisterController extends Controller{


    @FXML
    private Label lbldetails;

    @FXML
    private Label lblloginPasswordValidation;

    @FXML
    private TextField txtPassword;


    @FXML
    private TextField txtUserEmail;

    public static String saveEmail;



    public void Login(ActionEvent event){


        if (txtUserEmail.getText().trim().isEmpty() || txtPassword.getText().trim().isEmpty()) {
               //if user press the button withoute any input this will excicute and display this
            lblloginPasswordValidation.setText("Please enter Your email and \npassword before login.");


        }else {


               //this try catch for customer dataabse table
          try {
               //get the email and password value from dataabse
              String data = "SELECT `email`,`password` FROM `customerdb` WHERE `email`=? AND `password`=?";

              if (databaseChecking(data) == 1) {
                 // check whether the inputs are in dataabse
                  saveEmail = txtUserEmail.getText();
                    //store email valu to update email and other thing


                  Parent root = FXMLLoader.load(getClass().getResource("CustomerAccount.fxml"));
                  switchScene(event,root,"Jeff's Fishing Shack");


              } else {

                  lbldetails.setText("Login Failed"); //if inputs are nt in the dataabase then this line will display
                  lblloginPasswordValidation.setText("Please enter Your valid \nemail and password.");
              }

          }catch(Exception e){


          }

          try{
               //this try catch for staff datatabse table
              String data = "SELECT `email`,`password` FROM `staffdb` WHERE `email`=? AND `password`=?";

              if (databaseChecking(data) == 1) {
                  //if the inputs are in the staff table then staff memeber can access to thir account
                  saveEmail = txtUserEmail.getText();

                  lbldetails.setText("Login Successful");
                    //change to next interface
                  Parent root = FXMLLoader.load(getClass().getResource("StaffMemberAccount.fxml"));
                  switchScene(event,root,"Jeff's Fishing Shack");

              }
              else {
                //if the inputs are not match with datatabse then this line will excicute
                  lbldetails.setText("Login Failed");
                  lblloginPasswordValidation.setText("Please enter Your valid \nemail and password.");
              }


          }catch(Exception e){


          }


            try {
                  //this try catch for owner datatabse table
                String data = "SELECT `email`,`password` FROM `ownerdb` WHERE `email`=? AND `password`=?";

                if (databaseChecking(data) == 1) {
                    //if the inputs are in the owner table then owner can access to his or her account
                    saveEmail = txtUserEmail.getText();

                    lbldetails.setText("Login Successful");
                    //change to next interface
                    Parent root = FXMLLoader.load(getClass().getResource("OwnerAccount.fxml"));
                    switchScene(event,root,"Jeff's Fishing Shack");


                } else {
                    //if the inputs are not match with datatabse then this line will excicute
                    lbldetails.setText("Login Failed");
                    lblloginPasswordValidation.setText("Please enter Your valid \nemail and password.");
                }

            }catch(Exception e){


            }

        }
    }

    public int databaseChecking(String sqlr) throws SQLException {
        //get the database values
        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        PreparedStatement pre = connection.prepareStatement(sqlr);
         //search database values
        pre.setString(1, txtUserEmail.getText());
        pre.setString(2, txtPassword.getText());

        ResultSet res = pre.executeQuery();

        int dbcount = 0;
           //when dbcount is 1 it shows the email and password are in the database
        while (res.next()) {
            dbcount = dbcount + 1;

        }

        return dbcount;

    }



    public void SignUp(ActionEvent event) throws Exception {

          //switch to register interface
        Parent root = FXMLLoader.load(getClass().getResource("details.fxml"));
        switchScene(event,root,"Form");

    }



    @FXML
    private TextField textName;

    @FXML
    private TextField textEmail;

    @FXML
    private TextField textFormPassword;


    @FXML
    private Label lblForm;

    @FXML
    private TextField textConfirmPassword;




    public void Submit(ActionEvent event) throws SQLException, IOException {

       DatabaseConnection connectClass = new DatabaseConnection(); //get the database connection
       Connection connection = connectClass.getConnection();//by creating obj

           if (textName.getText().trim().isEmpty() || textEmail.getText().trim().isEmpty() || textFormPassword.getText().trim().isEmpty() || textConfirmPassword.getText().trim().isEmpty()){
               // if user doesn't input any values to text feild then it will display error message
               lblForm.setText("You didn't fill the form.\nPlease enter username,email and \npassword.");
               //display it on the interface
            }else {

               String data1 = "SELECT `email` FROM `customerdb` WHERE `email`=? ";  //get the email values from database customerdb table
               String data2 = "SELECT `email` FROM `staffdb` WHERE `email`=? ";   //get the email values from database  staffdb table
               String data3 = "SELECT `email` FROM `ownerdb` WHERE `email`=? ";  //get the email values from database  ownerdb table

               if (Validation.check(data1,textEmail.getText()) == 0 && Validation.check(data2,textEmail.getText()) == 0 && Validation.check(data3,textEmail.getText()) == 0) {
                    // check whether the user input email is already in the database

                   if (Validation.validateEmail(textEmail.getText())) {
                       //check whether the user input email is match to email structure

                       if (Validation.validationPassword(textFormPassword.getText()) >= 2) {
                           //check whether the password has at leaset 8 characters with 2 non-alphabetic charatcers

                           if (textFormPassword.getText().equals(textConfirmPassword.getText())) {
                              // check the password is match to confirm password
                               String sql = "INSERT INTO customerdb VALUES('" + textName.getText() + "','" + textFormPassword.getText() + "','" + textEmail.getText() + "');";
                                 //then insert all values to database table

                               System.out.println("Welcome");

                               Statement stat = connection.createStatement();
                               stat.executeUpdate(sql);
                                // change to the login interface
                               Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
                               switchScene(event,root,"Form");

                           } else {
                               //if the password doesn't match to confirm password then this statement will excicute
                               lblForm.setText("Enter above password again.");
                           }

                       } else {
                           //if the password doesn't have at least 8 characters with 2 non numeric characters then this statement will excicute
                           lblForm.setText("Enter 8 character password \nwith 2 non-alphabetic characters.");
                       }
                   } else {
                       //if the input email is doesn't match to email structure then this will excicute.
                       lblForm.setText("Enter Your email correctly.");
                   }

              } else {
                   //if the email is already in the database then this statement will excicute and display following line
                  lblForm.setText("This Email is already exist.");
               }
           }
    }

    public void SignIn(ActionEvent event) throws Exception {




        ((Node) (event.getSource())).getScene().getWindow().hide();
          //switch to login interface
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }













}
