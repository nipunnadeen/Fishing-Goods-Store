package sample;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class ManageStoreDetailsController extends Controller {




    @FXML
    private Label lblAddStoreItemValidation;
    @FXML
    private Label lblAddVerify;
    @FXML
    private TextField storeItemID;
    @FXML
    private TextField storeItemName;
    @FXML
    private TextField storeItemCode;
    @FXML
    private TextField storeItemPrice;
    @FXML
    private TextField storeItemAvailability;


    public void addProducts() throws SQLException {

         /*
        this method gives all validation and database connection to add the new product
        details to the database table.
         */

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection = connectionClass.getConnection();


        String storeData1 = "SELECT `ID` FROM `storedb` WHERE `ID`=? ";
        String storeData2 = "SELECT `ItemName` FROM `storedb` WHERE `ItemName`=? ";
        String storeData3 = "SELECT `Code` FROM `storedb` WHERE `Code`=? ";


        if (storeItemID.getText().trim().isEmpty() || storeItemName.getText().trim().isEmpty() || storeItemCode.getText().trim().isEmpty() || storeItemPrice.getText().trim().isEmpty() || storeItemAvailability.getText().trim().isEmpty()) {
             //if user press the button without any values this will statement will display the following message
            lblAddStoreItemValidation.setText("Enter all details of product \nbefore add to the store.");

        } else {
            //id,item name and code are unique
            if (Validation.storeCheckID(storeData1, storeItemID.getText()) == 0) { //if user input id isn't in the database this will execute
                  if(Validation.storeCheckItemName(storeData2, storeItemName.getText()) == 0){ //if user input item name isn't in the database this will execute
                      if(Validation.storeCheckCode(storeData3, storeItemCode.getText()) == 0){ //if user input code isn't in the database this will execute

                          String sql = "INSERT INTO storedb VALUES('" + storeItemID.getText() + "','" + storeItemName.getText() + "','" + storeItemCode.getText() + "','" + storeItemPrice.getText() + "','" + storeItemAvailability.getText() + "');";
                          //insert values to database

                          System.out.println("Welcome");

                          Statement statement = connection.createStatement();
                          statement.executeUpdate(sql);

                          lblAddVerify.setText("Product is successfully added");


                      }else{
                          //if the code is already in the database this line will execute
                          lblAddStoreItemValidation.setText("The product code is already exists.");
                      }

                  }else{
                      //if the item name is already in the database this line will execute
                      lblAddStoreItemValidation.setText("The product name is already exists.");
                  }
            } else {
                //if the id is already in the database this line will execute
                lblAddStoreItemValidation.setText("The product id is already exists.");
            }


        }
    }




    @FXML
    private Label lblUpdateNameValidation;

    @FXML
    private Label lblUpdateCodeValidation;

    @FXML
    private Label lblUpdatePriceValidation;

    @FXML
    private Label lblUpdateQuantityValidation;

    @FXML
    private TextField selectCurrentID;

    @FXML
    private TextField updateitemName;

    @FXML
    private TextField updateitemCode;

    @FXML
    private TextField updateitemPrice;

    @FXML
    private TextField updateitemQuantity;






    public void updateProductName()throws SQLException{

         /*
        this method gives all validation and database connection to update the product
        name of the database table.
         */

        DatabaseConnection connectionClass = new DatabaseConnection(); //get the database connection by calling class
        Connection connection = connectionClass.getConnection();

         //get the ite name column values  from data base
        String storeData = "SELECT `ItemName` FROM `storedb` WHERE `ItemName`=? ";

        if (updateitemName.getText().trim().isEmpty()) {
             //if user press the button without any values this will statement will display the following message
            lblUpdateNameValidation.setText("Enter product name \nbefore update.");

        } else {

            if (Validation.storeCheckItemName(storeData, updateitemName.getText()) == 0) {  //if user input item name isn't in the database this will execute

                try {
                    String iname = "UPDATE storedb SET  ItemName=? WHERE ID in('" + selectCurrentID.getText() + "')";
                    //get id location and update the item name

                    PreparedStatement prs = connection.prepareStatement(iname);


                    prs.setString(1, updateitemName.getText());
                     //update the itemname
                    prs.execute();

                    lblUpdateNameValidation.setText("Product item name is \nupdated.");
                    //when the update is successful then this line display on th screen



                } catch (Exception e) {
                    e.printStackTrace();
                }


            } else {
                //if the item name is already in the database this line will execute
                lblUpdateNameValidation.setText("Product name already exists.");
            }

        }
    }

    public void updateProductCode()throws SQLException {
        /*
        this method gives all validation and database connection to update the product
        code of the database table.
         */

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection = connectionClass.getConnection();


        String storeData = "SELECT `Code` FROM `storedb` WHERE `Code`=? ";

        if (updateitemCode.getText().trim().isEmpty()) {

            lblUpdateCodeValidation.setText("Enter product Code \nbefore update.");

        } else {

            if (Validation.storeCheckItemName(storeData, updateitemCode.getText()) == 0) {

                try {
                    String lol = "UPDATE storedb SET  Code=? WHERE ID in('" + selectCurrentID.getText() + "')";


                    PreparedStatement ps = connection.prepareStatement(lol);


                    ps.setString(1, updateitemCode.getText());

                    ps.execute();

                    lblUpdateCodeValidation.setText("Product item Code is \nupdated.");


                } catch (Exception e) {
                    e.printStackTrace();
                }


            } else {

                lblUpdateCodeValidation.setText("Product name already exists.");
            }

        }

    }

        public void updateProductPrice(){
        /*
        this method gives all validation and database connection to update the product
        price of the database table.
         */
            DatabaseConnection connectionClass = new DatabaseConnection();
            Connection connection = connectionClass.getConnection();


            if (updateitemPrice.getText().trim().isEmpty()) {

                lblUpdatePriceValidation.setText("Enter product Price \nbefore update.");

            } else {


                try {
                    String lol = "UPDATE storedb SET  Price=? WHERE ID in('" + selectCurrentID.getText() + "')";


                    PreparedStatement ps = connection.prepareStatement(lol);


                    ps.setString(1, updateitemPrice.getText());

                    ps.execute();

                    lblUpdatePriceValidation.setText("Product item Price is \nupdated.");


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            }

    public void updateProductQuantity(){

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection = connectionClass.getConnection();


        if (updateitemQuantity.getText().trim().isEmpty()) {

            lblUpdateQuantityValidation.setText("Enter product Quantity \nbefore update.");

        } else {


            try {
                String quant = "UPDATE storedb SET  Available=? WHERE ID in('" + selectCurrentID.getText() + "')";


                PreparedStatement ps = connection.prepareStatement(quant);


                ps.setString(1, updateitemQuantity.getText());

                ps.execute();

                lblUpdateQuantityValidation.setText("Product item Quantity is \nupdated.");


            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }





    public void backStaffStoreTable(ActionEvent event) throws IOException {

    Parent root = FXMLLoader.load(getClass().getResource("StaffManageStoreDetails.fxml"));
    switchScene(event, root, "Jeff's Fishing Shack");
}

    public void backOwnerStoreTable(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("OwnerManageStoreDetails.fxml"));
        switchScene(event, root, "Jeff's Fishing Shack");
    }
}
