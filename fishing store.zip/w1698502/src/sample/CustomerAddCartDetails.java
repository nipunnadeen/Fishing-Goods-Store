package sample;


public class CustomerAddCartDetails  {


    private String TableItemName;
    private String TableQuantity;
    private String TableTotal;


    public CustomerAddCartDetails(String TableItemName, String TableQuantity, String TableTotal){

        this.TableItemName = TableItemName;
        this.TableQuantity = TableQuantity;
        this.TableTotal = TableTotal;


    }

    public CustomerAddCartDetails(){


    }


    public String getTableItemName() {
        return TableItemName;
    }

    public void setTableItemName(String TableItemName) {
        this.TableItemName = TableItemName;
    }

    public String getTableQuantity() {
        return TableQuantity;
    }

    public void setTableQuantity(String TableQuantity) {
        this.TableQuantity = TableQuantity;
    }

    public String getTableTotal() {
        return TableTotal;
    }

    public void setTableTotal(String TableTotal) {
        this.TableTotal = TableTotal;
    }
}
