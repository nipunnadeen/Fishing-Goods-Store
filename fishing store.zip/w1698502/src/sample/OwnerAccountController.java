package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;




public class OwnerAccountController extends Controller {




    public void  manageStaffDetails(ActionEvent event) throws Exception {




        Parent root = FXMLLoader.load(getClass().getResource("OwnerStaffRegister.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");



    }




   public void  sendNewsLetters(ActionEvent event) throws Exception {




       Parent root = FXMLLoader.load(getClass().getResource("SendNewsLetters.fxml"));
       switchScene(event,root,"Jeff's Fishing Shack");

   }

    public void  manageStore(ActionEvent event) throws Exception {




        Parent root = FXMLLoader.load(getClass().getResource("OwnerManageStoreDetails.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }




    public void  accountSettings(ActionEvent event) throws Exception {




        Parent root = FXMLLoader.load(getClass().getResource("OwnerAccSettings.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }



    public void  logout(ActionEvent event) throws Exception {




        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }









}
