package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ManageStoreTableController implements Initializable {

    @FXML
    private TableView<ShowTable> manageTable;

    @FXML
    private TableColumn<ShowTable, String> collomn_ID;

    @FXML
    private TableColumn<ShowTable, String> collomn_ItemName;

    @FXML
    private TableColumn<ShowTable, String> collomn_Code;

    @FXML
    private TableColumn<ShowTable, String> collomn_Price;

    @FXML
    private TableColumn<ShowTable, String> collomn_Available;


    ObservableList<ShowTable> obsList = FXCollections.observableArrayList();


    @Override
    public void initialize(URL location, ResourceBundle resources) {


        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection = connectionClass.getConnection();


        try {
            ResultSet rs = connection.createStatement().executeQuery("SELECT * FROM `storedb` ");

            while(rs.next()){
                obsList.add(new ShowTable(rs.getString("ID"),rs.getString("ItemName"),rs.getString("Code"),rs.getString("Price"),rs.getString("Available")));

            }

        } catch (SQLException e) {

            e.printStackTrace();
        }


        collomn_ID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        collomn_ItemName.setCellValueFactory(new PropertyValueFactory<>("ItemName"));
        collomn_Code.setCellValueFactory(new PropertyValueFactory<>("Code"));
        collomn_Price.setCellValueFactory(new PropertyValueFactory<>("Price"));
        collomn_Available.setCellValueFactory(new PropertyValueFactory<>("Available"));


        manageTable.setItems(obsList);


    }

    public void addAndDeleteItems(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("OwnerAddDeleteStoreItems.fxml"));
        LoginAndRegisterController.switchScene(event, root, "Jeff's Fishing Shack");
    }

    public void updateItems(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("OwnerUpdateStoreItems.fxml"));
        LoginAndRegisterController.switchScene(event, root, "Jeff's Fishing Shack");
    }

    public void backOwner(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("OwnerAccount.fxml"));
        LoginAndRegisterController.switchScene(event, root, "Jeff's Fishing Shack");

    }

    public void backStaff(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("StaffMemberAccount.fxml"));
        LoginAndRegisterController.switchScene(event, root, "Jeff's Fishing Shack");

    }

}
