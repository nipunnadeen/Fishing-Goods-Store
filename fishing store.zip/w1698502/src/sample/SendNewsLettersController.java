package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class SendNewsLettersController extends Controller{


    @FXML
    private TextField txtSubject;

    @FXML
    private Label lblmailsuccessful;

    @FXML
    private TextArea txtBody;

    private static String USER_NAME = "romeo1997pp2cw@gmail.com";  // GMail user name (just the part before "@gmail.com")
    private static String PASSWORD = "romeo@123"; // GMail password


    public void send() throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        if(txtSubject.getText().trim().isEmpty() || txtBody.getText().trim().isEmpty()) {
            lblmailsuccessful.setText("fill the feilds");
        }else {

            String data = "SELECT `email` FROM `customerdb` ";

            PreparedStatement pst = connection.prepareStatement(data);

            ResultSet res = pst.executeQuery();


            while (res.next()) {
                String RECIPIENT = res.getString("email");

                String fromUser = USER_NAME;
                String pass = PASSWORD;
                String[] to = {RECIPIENT}; // list of recipient email addresses
                String subjectOfLetter = txtSubject.getText();
                String bodyOfLetter = txtBody.getText();

                sendFromGMail(fromUser, pass, to, subjectOfLetter, bodyOfLetter);
            }

            lblmailsuccessful.setText("Email Successfully sent");
        }
    }


    private static void sendFromGMail(String from, String pass, String[] to, String subject, String body) {
        Properties props = System.getProperties();
        String host = "smtp.gmail.com";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.password", pass);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");

        Session session = Session.getDefaultInstance(props);
        MimeMessage message = new MimeMessage(session);

        try {
            message.setFrom(new InternetAddress(from));
            InternetAddress[] toAddress = new InternetAddress[to.length];

            // To get the array of addresses
            for( int i = 0; i < to.length; i++ ) {
                toAddress[i] = new InternetAddress(to[i]);
            }

            for( int i = 0; i < toAddress.length; i++) {
                message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }

            message.setSubject(subject);
            message.setText(body);
            Transport transport = session.getTransport("smtp");
            transport.connect(host, from, pass);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
        }
        catch (AddressException ae) {
            ae.printStackTrace();
        }
        catch (MessagingException me) {
            me.printStackTrace();
        }
    }



 public void back(ActionEvent event) throws IOException {

     ((Node) (event.getSource())).getScene().getWindow().hide();

     //back to the owner account
     Parent root = FXMLLoader.load(getClass().getResource("OwnerAccount.fxml"));
     switchScene(event,root,"Jeff's Fishing Shack");

 }
}
