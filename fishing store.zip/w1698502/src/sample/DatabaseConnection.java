package sample;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    public Connection connection;
    //database connection method
    public  Connection getConnection(){

           //database name
        String jeffDatabaseName="jeff's_fishing_shack";
        String userName="root";  //default name
        String password="";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            //give the database path
            connection= DriverManager.getConnection("jdbc:mysql://localhost/"+jeffDatabaseName,userName,password);



        } catch (Exception e) { //send a error
            e.printStackTrace();
        }

       //return the value
        return connection;
    }



}
