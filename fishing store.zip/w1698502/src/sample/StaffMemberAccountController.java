package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class StaffMemberAccountController extends Controller {

    public void  manageStore(ActionEvent event) throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("StaffManageStoreDetails.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }

    public void  answerCustomersQueries(ActionEvent event) throws Exception {






    }

    public void  viewTransactions(ActionEvent event) throws Exception {






    }

    public void  accountSettings(ActionEvent event) throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("OwnerAccSettings.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }


    public void  logout(ActionEvent event) throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }




}
