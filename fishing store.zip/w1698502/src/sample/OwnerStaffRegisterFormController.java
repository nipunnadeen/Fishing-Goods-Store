package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class OwnerStaffRegisterFormController extends Controller{



    @FXML
    private TextField stafftextUsername;

    @FXML
    private TextField stafftextEmail;

    @FXML
    private TextField stafftextPassword;

    @FXML
    private TextField stafftextConfirmPassword;


    @FXML
    private Label lblstaffValidation;

    @FXML
    private Label lblstaffaddverify;

    @FXML
    private Label lblstaffdeleteverify;

    @FXML
    private TextField staffdeletemember;



   public void staffAdd()throws Exception{

       DatabaseConnection connectClass = new DatabaseConnection();
       Connection connection = connectClass.getConnection();




       if (stafftextUsername.getText().trim().isEmpty() || stafftextEmail.getText().trim().isEmpty() || stafftextPassword.getText().trim().isEmpty() || stafftextConfirmPassword.getText().trim().isEmpty()){
            // if user press the button without fill the form this statemenet will excute.
           lblstaffValidation.setText("You didn't fill the form.\nPlease enter staff member username,email and \npassword before add.");

       }else {

           String data1 = "SELECT `email` FROM `customerdb` WHERE `email`=? ";  //get the email values from the 3 tables
           String data2 = "SELECT `email` FROM `staffdb` WHERE `email`=? ";
           String data3 = "SELECT `email` FROM `ownerdb` WHERE `email`=? ";

           if (Validation.check(data1,stafftextEmail.getText()) == 0 && Validation.check(data2,stafftextEmail.getText()) == 0 && Validation.check(data3,stafftextEmail.getText()) == 0) {
                   //if the email value is not thir in the dtatabse this statement will execute
               if (Validation.validateEmail(stafftextEmail.getText())) {
                    //check the user input is match to email structure
                   if (Validation.validationPassword(stafftextPassword.getText()) >= 2) {
                       //check whether the password have at least 2 non numeric characters and check password has 8 characters.
                       if (stafftextPassword.getText().equals(stafftextConfirmPassword.getText())) {
                           //check whether password is equaled to confirm password
                           String add = "INSERT INTO staffdb VALUES('" + stafftextUsername.getText() + "','" + stafftextPassword.getText() + "','" + stafftextEmail.getText() + "');";
                          //insert the user values to database
                           System.out.println("Welcome");

                           Statement statement = connection.createStatement();
                           statement.executeUpdate(add);

                           lblstaffaddverify.setText("Staff Member Adding Successful");

                       } else {
                              //if user doesn't input password to confirm password this line will display
                           lblstaffValidation.setText("Enter above password again.");


                       }

                   } else {
                       //if user doesn't input password doesn't have at least 2 non numeric charactrs and 8 characters this line will display
                       lblstaffValidation.setText("Enter 8 character password \nwith 2 non-alphabetic characters.");
                   }
               } else {
                   //if email doesn't match to email structure then this line will display
                   lblstaffValidation.setText("Enter Your email correctly.");
               }

           } else {
               //if the user input email value is already in the database then this line will display as a eror message
               lblstaffValidation.setText("This Email is already exist.");
           }
       }





   }




    public void Back(ActionEvent event)throws Exception{



        ((Node) (event.getSource())).getScene().getWindow().hide();

           //back to the owner account
        Parent root = FXMLLoader.load(getClass().getResource("OwnerAccount.fxml"));
        switchScene(event,root,"Jeff's Fishing Shack");

    }

}
